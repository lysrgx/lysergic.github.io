//////////////////////////////////////////////////////////////////////

Map Title                : zombie island
Map Version              : Beta
Author                   : GrandBlaarg
Website                  : www.oldfartsatwar.com  
//////////////////////////////////////////////////////////////////////

Game                     : Call of Duty: World at War 
 
Supported Gametype       : Cooperative
                         : Singleplayer
                         : Co-op zombies


//////////////////////////////////////////////////////////////////////

Contents of this Package :
zombie island folder  containing
     	
      nazi_zombie_island.ff
	mod.arena		
       		
			
//////////////////////////////////////////////////////////////////////






//////////////////////////////////////////////////////////////////////

Installation Instructions:

     Extract to--
(XP)C:\Documents and Settings\YOUR_PROFILE\Local Settings\Application Data\Activision\CoDWaW\mods\
(vista)C:\Users\YOUR_PROFILE\AppData\Local\Activision\CoDWaW\mods\

To play the map first go into mods and select zombie island

SOLO Playing: If you wish to play alone then open console
              (~) and type "/map nazi_zombie_island".  


//////////////////////////////////////////////////////////////////////



